import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b2f08eeb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b2f08eeb"; const useState = __vite__cjsImport3_react["useState"];
import "/src/frontend/styles/main.css";
import { REPLHistory } from "/src/frontend/components/REPLHistory.tsx";
import { REPLInput } from "/src/frontend/components/REPLInput.tsx";
import WrappedMap from "/src/frontend/components/map/WrappedMap.tsx?t=1699747925689";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([]);
  const [mode, setMode] = useState("brief");
  const [commandResultMap, setCommandResultMap] = useState(/* @__PURE__ */ new Map());
  const [showMap, setShowMap] = useState(true);
  function updateCommandResult(command, result) {
    const historyItem = {
      command,
      timestamp: (/* @__PURE__ */ new Date()).getTime()
    };
    commandResultMap.set(historyItem, result);
    setHistory((prevHistory) => [...prevHistory, historyItem]);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "button-container", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowMap(!showMap), children: showMap ? "Show REPL" : "Show Map" }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
      lineNumber: 38,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    showMap ? /* @__PURE__ */ jsxDEV("div", { className: "map-container", children: /* @__PURE__ */ jsxDEV(WrappedMap, {}, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
      lineNumber: 44,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
      lineNumber: 43,
      columnNumber: 18
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "repl-container", children: [
      /* @__PURE__ */ jsxDEV(REPLHistory, { commandHistory: history, mode, commandResultMap, ariaLabel: "History Log Display to show past commands inputted" }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
        lineNumber: 46,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
        lineNumber: 47,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(REPLInput, { history, setHistory, mode, setMode, commandResultMap, updateCommandResult, ariaLabel: "Input Command Component to take in and process command inputs" }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
        lineNumber: 48,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
      lineNumber: 45,
      columnNumber: 18
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx",
    lineNumber: 36,
    columnNumber: 10
  }, this);
}
_s(REPL, "VxRss/UVJJb2S/UaIepqqdCtryA=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJDUixTQUFtQ0EsZ0JBQWdCO0FBQ25ELE9BQU87QUFDUCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBRTFCLE9BQU9DLGdCQUFnQjtBQVN2Qix3QkFBd0JDLE9BQU87QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSVAsU0FBd0IsRUFBRTtBQUN4RCxRQUFNLENBQUNRLE1BQU1DLE9BQU8sSUFBSVQsU0FBaUIsT0FBTztBQUNoRCxRQUFNLENBQUNVLGtCQUFrQkMsbUJBQW1CLElBQUlYLFNBQVMsb0JBQUlZLElBQUksQ0FBQztBQUNsRSxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSWQsU0FBUyxJQUFJO0FBTzNDLFdBQVNlLG9CQUFvQkMsU0FBaUJDLFFBQXVCO0FBQ25FLFVBQU1DLGNBQTJCO0FBQUEsTUFDL0JGO0FBQUFBLE1BQ0FHLFlBQVcsb0JBQUlDLEtBQUssR0FBRUMsUUFBUTtBQUFBLElBQ2hDO0FBQ0FYLHFCQUFpQlksSUFBSUosYUFBYUQsTUFBTTtBQUN4Q1YsZUFBWWdCLGlCQUFnQixDQUFDLEdBQUdBLGFBQWFMLFdBQVcsQ0FBQztBQUFBLEVBQzNEO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxZQUFPLFNBQVMsTUFBTUosV0FBVyxDQUFDRCxPQUFPLEdBQ3ZDQSxvQkFBVSxjQUFjLGNBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUNBLFVBQ0MsdUJBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVyxLQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDZCQUFDLGVBQ0MsZ0JBQWdCUCxTQUNoQixNQUNBLGtCQUNBLFdBQVUsd0RBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlnRTtBQUFBLE1BRWhFLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFJO0FBQUEsTUFDSix1QkFBQyxhQUNDLFNBQ0EsWUFDQSxNQUNBLFNBQ0Esa0JBQ0EscUJBQ0EsV0FBVSxtRUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTzJFO0FBQUEsU0FmN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQkE7QUFFSjtBQUFDRCxHQXREdUJELE1BQUk7QUFBQW9CLEtBQUpwQjtBQUFJLElBQUFvQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJSRVBMSGlzdG9yeSIsIlJFUExJbnB1dCIsIldyYXBwZWRNYXAiLCJSRVBMIiwiX3MiLCJoaXN0b3J5Iiwic2V0SGlzdG9yeSIsIm1vZGUiLCJzZXRNb2RlIiwiY29tbWFuZFJlc3VsdE1hcCIsInNldENvbW1hbmRSZXN1bHRNYXAiLCJNYXAiLCJzaG93TWFwIiwic2V0U2hvd01hcCIsInVwZGF0ZUNvbW1hbmRSZXN1bHQiLCJjb21tYW5kIiwicmVzdWx0IiwiaGlzdG9yeUl0ZW0iLCJ0aW1lc3RhbXAiLCJEYXRlIiwiZ2V0VGltZSIsInNldCIsInByZXZIaXN0b3J5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IFJFUExIaXN0b3J5IH0gZnJvbSBcIi4vUkVQTEhpc3RvcnlcIjtcbmltcG9ydCB7IFJFUExJbnB1dCB9IGZyb20gXCIuL1JFUExJbnB1dFwiO1xuaW1wb3J0IHsgSGlzdG9yeUl0ZW0gfSBmcm9tIFwiLi4vdHlwZXMvSGlzdG9yeUl0ZW1cIjtcbmltcG9ydCBXcmFwcGVkTWFwIGZyb20gXCIuL21hcC9XcmFwcGVkTWFwXCI7XG5pbXBvcnQgeyBNYXBJbnB1dCB9IGZyb20gXCIuL21hcC9NYXBJbnB1dFwiO1xuXG4vKipcbiAqIFJlYWN0IGNvbXBvbmVudCBhbGxvd2luZyB1c2VycyB0byBpbnB1dCBjb21tYW5kcztcbiAqIERpc3BsYXlzIGNvcnJlc3BvbmRpbmcgY29tbWFuZCBoaXN0b3J5LCBhbmQgc2hvd3MgdGhlIHJlc3VsdHMgb2YgZWFjaCBjb21tYW5kLlxuICogRGVwZW5kaW5nIG9uIHRoZSBtb2RlIHNlbGVjdGVkLCBjYW4gZGlzcGxheSBlaXRoZXIganVzdCB0aGUgb3V0cHV0LFxuICogb3IgYm90aCB0aGUgdXNlcidzIGNvbW1hbmQgYW5kIHRoZSBvdXRwdXQuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJFUEwoKSB7XG4gIGNvbnN0IFtoaXN0b3J5LCBzZXRIaXN0b3J5XSA9IHVzZVN0YXRlPEhpc3RvcnlJdGVtW10+KFtdKTtcbiAgY29uc3QgW21vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8c3RyaW5nPihcImJyaWVmXCIpO1xuICBjb25zdCBbY29tbWFuZFJlc3VsdE1hcCwgc2V0Q29tbWFuZFJlc3VsdE1hcF0gPSB1c2VTdGF0ZShuZXcgTWFwKCkpO1xuICBjb25zdCBbc2hvd01hcCwgc2V0U2hvd01hcF0gPSB1c2VTdGF0ZSh0cnVlKTtcblxuICAvKipcbiAgICogVXBkYXRlIHRoZSBjb21tYW5kIHJlc3VsdCBhbmQgYWRkIGl0IHRvIHRoZSBjb21tYW5kIGhpc3RvcnkuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBjb21tYW5kIC0gVGhlIHVzZXIncyBpbnB1dCBjb21tYW5kLlxuICAgKiBAcGFyYW0ge1tbXV0gfCBzdHJpbmcgfSByZXN1bHQgLSBUaGUgcmVzdWx0IG9mIHRoZSBjb21tYW5kIGV4ZWN1dGlvbi5cbiAgICovXG4gIGZ1bmN0aW9uIHVwZGF0ZUNvbW1hbmRSZXN1bHQoY29tbWFuZDogc3RyaW5nLCByZXN1bHQ6IFtbXV0gfCBzdHJpbmcpIHtcbiAgICBjb25zdCBoaXN0b3J5SXRlbTogSGlzdG9yeUl0ZW0gPSB7XG4gICAgICBjb21tYW5kOiBjb21tYW5kLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLmdldFRpbWUoKSxcbiAgICB9O1xuICAgIGNvbW1hbmRSZXN1bHRNYXAuc2V0KGhpc3RvcnlJdGVtLCByZXN1bHQpO1xuICAgIHNldEhpc3RvcnkoKHByZXZIaXN0b3J5KSA9PiBbLi4ucHJldkhpc3RvcnksIGhpc3RvcnlJdGVtXSk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJidXR0b24tY29udGFpbmVyXCI+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd01hcCghc2hvd01hcCl9PlxuICAgICAgICAgIHtzaG93TWFwID8gXCJTaG93IFJFUExcIiA6IFwiU2hvdyBNYXBcIn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAge3Nob3dNYXAgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWNvbnRhaW5lclwiPlxuICAgICAgICAgIDxXcmFwcGVkTWFwIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWNvbnRhaW5lclwiPlxuICAgICAgICAgIDxSRVBMSGlzdG9yeVxuICAgICAgICAgICAgY29tbWFuZEhpc3Rvcnk9e2hpc3Rvcnl9XG4gICAgICAgICAgICBtb2RlPXttb2RlfVxuICAgICAgICAgICAgY29tbWFuZFJlc3VsdE1hcD17Y29tbWFuZFJlc3VsdE1hcH1cbiAgICAgICAgICAgIGFyaWFMYWJlbD1cIkhpc3RvcnkgTG9nIERpc3BsYXkgdG8gc2hvdyBwYXN0IGNvbW1hbmRzIGlucHV0dGVkXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxocj48L2hyPlxuICAgICAgICAgIDxSRVBMSW5wdXRcbiAgICAgICAgICAgIGhpc3Rvcnk9e2hpc3Rvcnl9XG4gICAgICAgICAgICBzZXRIaXN0b3J5PXtzZXRIaXN0b3J5fVxuICAgICAgICAgICAgbW9kZT17bW9kZX1cbiAgICAgICAgICAgIHNldE1vZGU9e3NldE1vZGV9XG4gICAgICAgICAgICBjb21tYW5kUmVzdWx0TWFwPXtjb21tYW5kUmVzdWx0TWFwfVxuICAgICAgICAgICAgdXBkYXRlQ29tbWFuZFJlc3VsdD17dXBkYXRlQ29tbWFuZFJlc3VsdH1cbiAgICAgICAgICAgIGFyaWFMYWJlbD1cIklucHV0IENvbW1hbmQgQ29tcG9uZW50IHRvIHRha2UgaW4gYW5kIHByb2Nlc3MgY29tbWFuZCBpbnB1dHNcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3pkemlsb3dza2EvRGVza3RvcC91bml2ZXJzaXR5L3llYXIgMi9jczAzMjAvbWFwcy1qemR6aWxvdy1zcHNhbmRvdi9zcmMvZnJvbnRlbmQvY29tcG9uZW50cy9SRVBMLnRzeCJ9