export const type = "FeatureCollection";
export const features = [
	{
		type: "Feature",
		geometry: {
			type: "MultiPolygon",
			coordinates: [
				[
					[
						[
							-86.756777,
							33.497543
						],
						[
							-86.75692,
							33.495789
						],
						[
							-86.762018,
							33.491924
						],
						[
							-86.762268,
							33.488921
						],
						[
							-86.754496,
							33.488832
						],
						[
							-86.753961,
							33.487642
						],
						[
							-86.752891,
							33.486899
						],
						[
							-86.75225,
							33.487791
						],
						[
							-86.75225,
							33.490437
						],
						[
							-86.752178,
							33.491745
						],
						[
							-86.752071,
							33.492102
						],
						[
							-86.746046,
							33.496621
						],
						[
							-86.745904,
							33.497038
						],
						[
							-86.745797,
							33.500159
						],
						[
							-86.745079,
							33.499216
						],
						[
							-86.744128,
							33.49878
						],
						[
							-86.743415,
							33.498661
						],
						[
							-86.743178,
							33.497432
						],
						[
							-86.743273,
							33.49656
						],
						[
							-86.743938,
							33.495806
						],
						[
							-86.744889,
							33.495251
						],
						[
							-86.745032,
							33.494062
						],
						[
							-86.744651,
							33.493071
						],
						[
							-86.744128,
							33.492437
						],
						[
							-86.742892,
							33.492952
						],
						[
							-86.741799,
							33.493032
						],
						[
							-86.740658,
							33.492992
						],
						[
							-86.739755,
							33.492675
						],
						[
							-86.73947,
							33.492199
						],
						[
							-86.739375,
							33.491803
						],
						[
							-86.739898,
							33.491446
						],
						[
							-86.740563,
							33.491049
						],
						[
							-86.740896,
							33.490256
						],
						[
							-86.740278,
							33.489503
						],
						[
							-86.735619,
							33.491327
						],
						[
							-86.735334,
							33.492199
						],
						[
							-86.734811,
							33.494023
						],
						[
							-86.726207,
							33.4987
						],
						[
							-86.725637,
							33.498502
						],
						[
							-86.725257,
							33.497987
						],
						[
							-86.724829,
							33.497471
						],
						[
							-86.729107,
							33.492794
						],
						[
							-86.732054,
							33.490296
						],
						[
							-86.732577,
							33.489543
						],
						[
							-86.733243,
							33.488909
						],
						[
							-86.736285,
							33.486966
						],
						[
							-86.738614,
							33.485142
						],
						[
							-86.740021,
							33.484508
						],
						[
							-86.740497,
							33.485499
						],
						[
							-86.741305,
							33.485578
						],
						[
							-86.742446,
							33.485697
						],
						[
							-86.743254,
							33.485578
						],
						[
							-86.744299,
							33.484944
						],
						[
							-86.745155,
							33.484825
						],
						[
							-86.745963,
							33.485142
						],
						[
							-86.746201,
							33.484904
						],
						[
							-86.747247,
							33.484667
						],
						[
							-86.747912,
							33.484548
						],
						[
							-86.74853,
							33.483993
						],
						[
							-86.74872,
							33.48312
						],
						[
							-86.75143,
							33.4809
						],
						[
							-86.754377,
							33.477807
						],
						[
							-86.755375,
							33.477847
						],
						[
							-86.756374,
							33.477411
						],
						[
							-86.757277,
							33.476856
						],
						[
							-86.757467,
							33.476102
						],
						[
							-86.757847,
							33.475785
						],
						[
							-86.758941,
							33.47527
						],
						[
							-86.760081,
							33.474794
						],
						[
							-86.76089,
							33.474278
						],
						[
							-86.761365,
							33.473604
						],
						[
							-86.761222,
							33.473089
						],
						[
							-86.761222,
							33.472256
						],
						[
							-86.761365,
							33.47186
						],
						[
							-86.761603,
							33.471542
						],
						[
							-86.762648,
							33.472018
						],
						[
							-86.763647,
							33.47293
						],
						[
							-86.764027,
							33.473565
						],
						[
							-86.763456,
							33.474556
						],
						[
							-86.763266,
							33.475111
						],
						[
							-86.763742,
							33.476063
						],
						[
							-86.764787,
							33.476816
						],
						[
							-86.766118,
							33.477411
						],
						[
							-86.767925,
							33.478323
						],
						[
							-86.768353,
							33.478759
						],
						[
							-86.769351,
							33.480067
						],
						[
							-86.769779,
							33.480741
						],
						[
							-86.771015,
							33.481415
						],
						[
							-86.772346,
							33.48201
						],
						[
							-86.773296,
							33.483081
						],
						[
							-86.773059,
							33.483437
						],
						[
							-86.772964,
							33.483794
						],
						[
							-86.773106,
							33.484191
						],
						[
							-86.772441,
							33.484548
						],
						[
							-86.772203,
							33.484944
						],
						[
							-86.77206,
							33.485539
						],
						[
							-86.77168,
							33.486173
						],
						[
							-86.77111,
							33.486966
						],
						[
							-86.768971,
							33.488393
						],
						[
							-86.767354,
							33.489305
						],
						[
							-86.766641,
							33.490058
						],
						[
							-86.765881,
							33.490574
						],
						[
							-86.764787,
							33.490891
						],
						[
							-86.763361,
							33.491723
						],
						[
							-86.761935,
							33.492635
						],
						[
							-86.761127,
							33.493705
						],
						[
							-86.761222,
							33.494023
						],
						[
							-86.76184,
							33.494023
						],
						[
							-86.762458,
							33.494498
						],
						[
							-86.762458,
							33.494895
						],
						[
							-86.762078,
							33.495291
						],
						[
							-86.76146,
							33.495806
						],
						[
							-86.760652,
							33.497313
						],
						[
							-86.760462,
							33.498185
						],
						[
							-86.760319,
							33.498462
						],
						[
							-86.758132,
							33.50088
						],
						[
							-86.757241,
							33.501794
						],
						[
							-86.756528,
							33.501765
						],
						[
							-86.756777,
							33.497543
						]
					]
				]
			]
		},
		properties: {
			state: "AL",
			city: "Birmingham",
			name: "Mountain Brook Estates and Country Club Gardens (outside city limits)",
			holc_id: "A1",
			holc_grade: "A",
			neighborhood_id: 244,
			area_description_data: {
				"5": "Both sales and rental prices in 1929 were off about 20% from 1925-28 peak. Location of property within this area will justify policy of holding for its value.",
				"6": "Mountain Brook Estates and County Club Gardens (outside city limits) Ample 1",
				"31": "40%",
				"32": "10%",
				"33": "50%",
				"1c": "Residents of area required to pay moderate school tuition if students attend city schools (usually pertains only to high school students). Bus transportation available only to north edge.",
				"1b": "Highly restricted. Near two high grade country clubs. in valley south of Red Mountain; hence protected from industrial ordors and noises of city. Outside of city limits; therefore subject to lower taxation. One of the community's newest localities. Large lots; well landscaped. Layout of community adds charm and appeal. Community stores. Schools.",
				"3n": "50-100 62 75-125 1936 No rentals N/A N/A",
				"1d": "35%",
				"3d": "Excellent Excellent Excellent",
				"1e": "Up",
				"2b": "5000-50,000 (with few $100,000)",
				"3h": "15000-35000 None 35000-90000",
				"3p": "No rentals Good to fair Poor",
				"2f": "None",
				"1a": "Hilly and roling to undulating",
				"3o": "N/A No rentals 100-150 N/A 75 60-125 1938",
				"3q": "No rentals Poor Good to fair",
				"3m": "No rentals 90-150 No rentals",
				"3a": "2 story singles 2 story singles 2 story singles",
				"3j": "72% 25000-60000 1938 10000-25000 11000-25000 69 N/A",
				"2g": "N/A N/A Moderately",
				"3l": "Fair Good Poor",
				"2d": "None N/A",
				"3k": "Good Poor Good",
				"3f": "85% 100% 90%",
				"4a": "Ample",
				"3e": "95% 99% 98%",
				"3b": "Brick Veneer Brick Veneer Brick Veneer",
				"3i": "11000-25000 N/A 72% 69 1936 10000-25000 25000-60000",
				"2a": "Executives, business men, and retired professional men",
				"4b": "Ample",
				"3g": "65 ($10,000-25,000) None None",
				"3c": "2 10 10",
				"2e": "None",
				"2c": "None N/A"
			}
		}
	},
	{
		type: "Feature",
		geometry: {
			type: "MultiPolygon",
			coordinates: [
				[
					[
						[
							-82.561819,
							35.621754
						],
						[
							-82.561329,
							35.621273
						],
						[
							-82.560639,
							35.620693
						],
						[
							-82.559665,
							35.620558
						],
						[
							-82.558809,
							35.620558
						],
						[
							-82.558738,
							35.618085
						],
						[
							-82.55888,
							35.616539
						],
						[
							-82.558096,
							35.614104
						],
						[
							-82.557882,
							35.61252
						],
						[
							-82.557621,
							35.611612
						],
						[
							-82.557145,
							35.607477
						],
						[
							-82.554673,
							35.607496
						],
						[
							-82.555244,
							35.610182
						],
						[
							-82.555529,
							35.611187
						],
						[
							-82.555764,
							35.612824
						],
						[
							-82.555597,
							35.614718
						],
						[
							-82.554944,
							35.617171
						],
						[
							-82.555146,
							35.621934
						],
						[
							-82.555205,
							35.624098
						],
						[
							-82.5549,
							35.62511
						],
						[
							-82.553959,
							35.627034
						],
						[
							-82.553616,
							35.628355
						],
						[
							-82.553695,
							35.629565
						],
						[
							-82.550337,
							35.630243
						],
						[
							-82.550242,
							35.630011
						],
						[
							-82.550503,
							35.628949
						],
						[
							-82.550515,
							35.628147
						],
						[
							-82.550266,
							35.628089
						],
						[
							-82.550503,
							35.624863
						],
						[
							-82.550682,
							35.62381
						],
						[
							-82.550872,
							35.623027
						],
						[
							-82.55149,
							35.622486
						],
						[
							-82.553249,
							35.621839
						],
						[
							-82.553118,
							35.620274
						],
						[
							-82.553094,
							35.617105
						],
						[
							-82.553344,
							35.61327
						],
						[
							-82.553688,
							35.611193
						],
						[
							-82.553522,
							35.610478
						],
						[
							-82.552809,
							35.608681
						],
						[
							-82.552037,
							35.608111
						],
						[
							-82.550385,
							35.607811
						],
						[
							-82.54575,
							35.607048
						],
						[
							-82.545904,
							35.604729
						],
						[
							-82.546095,
							35.600854
						],
						[
							-82.543397,
							35.600883
						],
						[
							-82.540378,
							35.600796
						],
						[
							-82.540747,
							35.600352
						],
						[
							-82.541911,
							35.600303
						],
						[
							-82.542957,
							35.599801
						],
						[
							-82.54569,
							35.598835
						],
						[
							-82.546047,
							35.598236
						],
						[
							-82.546522,
							35.597694
						],
						[
							-82.547212,
							35.597327
						],
						[
							-82.547782,
							35.596728
						],
						[
							-82.548376,
							35.596747
						],
						[
							-82.549018,
							35.597028
						],
						[
							-82.549458,
							35.598429
						],
						[
							-82.550004,
							35.599415
						],
						[
							-82.552215,
							35.598902
						],
						[
							-82.552999,
							35.598757
						],
						[
							-82.553558,
							35.59896
						],
						[
							-82.554627,
							35.599743
						],
						[
							-82.555091,
							35.599067
						],
						[
							-82.556089,
							35.598361
						],
						[
							-82.559381,
							35.596506
						],
						[
							-82.55931,
							35.595694
						],
						[
							-82.55944,
							35.59495
						],
						[
							-82.559226,
							35.592959
						],
						[
							-82.558644,
							35.592534
						],
						[
							-82.557563,
							35.592525
						],
						[
							-82.556279,
							35.592689
						],
						[
							-82.55641,
							35.58863
						],
						[
							-82.556243,
							35.587374
						],
						[
							-82.556683,
							35.5872
						],
						[
							-82.557551,
							35.58661
						],
						[
							-82.558371,
							35.585228
						],
						[
							-82.558727,
							35.584387
						],
						[
							-82.560296,
							35.584416
						],
						[
							-82.560284,
							35.585943
						],
						[
							-82.560391,
							35.586697
						],
						[
							-82.56051,
							35.588089
						],
						[
							-82.560759,
							35.589867
						],
						[
							-82.561223,
							35.591094
						],
						[
							-82.561972,
							35.592225
						],
						[
							-82.562185,
							35.593269
						],
						[
							-82.562958,
							35.594148
						],
						[
							-82.560498,
							35.596371
						],
						[
							-82.56089,
							35.597057
						],
						[
							-82.562162,
							35.598023
						],
						[
							-82.564194,
							35.59696
						],
						[
							-82.567581,
							35.595743
						],
						[
							-82.568425,
							35.595878
						],
						[
							-82.568793,
							35.596419
						],
						[
							-82.568674,
							35.597501
						],
						[
							-82.566773,
							35.598583
						],
						[
							-82.566309,
							35.59869
						],
						[
							-82.564598,
							35.59953
						],
						[
							-82.564527,
							35.600603
						],
						[
							-82.564752,
							35.601289
						],
						[
							-82.565358,
							35.602023
						],
						[
							-82.563338,
							35.602999
						],
						[
							-82.566761,
							35.607386
						],
						[
							-82.567581,
							35.608082
						],
						[
							-82.568341,
							35.608323
						],
						[
							-82.570029,
							35.608488
						],
						[
							-82.572358,
							35.608314
						],
						[
							-82.57357,
							35.608062
						],
						[
							-82.574473,
							35.607773
						],
						[
							-82.576185,
							35.607067
						],
						[
							-82.577135,
							35.606478
						],
						[
							-82.577385,
							35.606893
						],
						[
							-82.577266,
							35.607985
						],
						[
							-82.576197,
							35.610246
						],
						[
							-82.575686,
							35.611908
						],
						[
							-82.575531,
							35.612294
						],
						[
							-82.573927,
							35.613956
						],
						[
							-82.57256,
							35.614458
						],
						[
							-82.571051,
							35.614487
						],
						[
							-82.570374,
							35.614207
						],
						[
							-82.569554,
							35.61328
						],
						[
							-82.568745,
							35.612768
						],
						[
							-82.567189,
							35.612314
						],
						[
							-82.566428,
							35.611666
						],
						[
							-82.565858,
							35.61069
						],
						[
							-82.565347,
							35.609744
						],
						[
							-82.564253,
							35.608855
						],
						[
							-82.562922,
							35.607859
						],
						[
							-82.560367,
							35.608362
						],
						[
							-82.559298,
							35.608159
						],
						[
							-82.55963,
							35.609686
						],
						[
							-82.560664,
							35.61155
						],
						[
							-82.561472,
							35.612391
						],
						[
							-82.561924,
							35.613569
						],
						[
							-82.562292,
							35.613995
						],
						[
							-82.562435,
							35.614516
						],
						[
							-82.562209,
							35.617463
						],
						[
							-82.562043,
							35.621057
						],
						[
							-82.561819,
							35.621754
						]
					]
				]
			]
		},
		properties: {
			state: "NC",
			city: "Asheville",
			name: null,
			holc_id: "C2",
			holc_grade: "C",
			neighborhood_id: 168,
			area_description_data: {
				"1": "C Asheville, N.C. 2",
				"2": "Rolling to hilly.",
				"3": "All city conveniences, adequate transportation, close to main business section, schools, churches, etc.",
				"4": "Merriman Avenue heavy traffic artery.  Encroachment of Tourist Homes and apartments.  Tuberculosis sanitarium on Barnard Avenue, Hospital on Woodfin.  Older type of properties. Boarding and Rooming houses in area.",
				"7": "1925-1926 1925-1926 87% 3,000  1933 15-75 5,000 $1500-20,000 1500-15,000 25 130% 70% 1000-12,500 60% 3,500 35 130 $15-100 10-60 60% $40",
				"13": "Static to downward",
				"14": "Along Merriman Avenue some large, expensive homes still occupied by owners, but great majority being turned into Tourist Homes by owners to increase income, or being purchased by others for this purpose.  Montford Avenue, formerly one of best residential streets in city.  Flint and Cumberland also good residential streets, but boarding and rooming houses are gradually encroaching.  Good negro section on Crescent, Madison and Lee, ten years ago occupied entirely by whites.  Also lower type negro section on Short Street and at North end of Flint St.  Business gradually expanding into this area on most every side of present main business district.",
				"15": "7 Sept. 1 Wm. Coleman, Loan Service Field Representative.",
				"9c": "Fair",
				"11b": "None",
				"9a": "Fair",
				"10c": "Good",
				"6c": "30 years",
				"5b": "1000-5000",
				"10b": "Apartments - Small singles, large singles for tourist purposes",
				"5e": "Negro slowly in area, around Crescent, Madison and Lee Streets.",
				"5a": "Every type except lowest",
				"6b": "Frame and Brick Veneer",
				"9b": "Large homes for use as tourist homes",
				"5f": "Few",
				"5g": " ",
				"10a": "Good",
				"6a": "Large and small singles, Duplexes - Apartments",
				"11a": "None",
				"8c": "35%",
				"5c": "Yes 1",
				"8a": "90%",
				"12a": "Limited",
				"8b": "100",
				"6d": "Fair to poor",
				"5d": "Yes 2",
				"12b": "Limited"
			}
		}
	},
	{
		type: "Feature",
		geometry: {
			type: "MultiPolygon",
			coordinates: [
				[
					[
						[
							-86.758669,
							33.509329
						],
						[
							-86.760927,
							33.508066
						],
						[
							-86.756886,
							33.503632
						],
						[
							-86.757421,
							33.503384
						],
						[
							-86.758045,
							33.50326
						],
						[
							-86.759471,
							33.503706
						],
						[
							-86.761194,
							33.501625
						],
						[
							-86.762501,
							33.501154
						],
						[
							-86.763393,
							33.500758
						],
						[
							-86.763868,
							33.500262
						],
						[
							-86.765175,
							33.498825
						],
						[
							-86.765562,
							33.498255
						],
						[
							-86.766245,
							33.497859
						],
						[
							-86.767225,
							33.49776
						],
						[
							-86.768414,
							33.497859
						],
						[
							-86.769157,
							33.497537
						],
						[
							-86.769751,
							33.497066
						],
						[
							-86.771296,
							33.496794
						],
						[
							-86.773346,
							33.495431
						],
						[
							-86.774296,
							33.495382
						],
						[
							-86.774207,
							33.493796
						],
						[
							-86.778456,
							33.49392
						],
						[
							-86.778426,
							33.493672
						],
						[
							-86.781219,
							33.493697
						],
						[
							-86.781367,
							33.496026
						],
						[
							-86.793923,
							33.490401
						],
						[
							-86.794547,
							33.492532
						],
						[
							-86.794576,
							33.493077
						],
						[
							-86.794131,
							33.493771
						],
						[
							-86.792776,
							33.494737
						],
						[
							-86.790548,
							33.494267
						],
						[
							-86.785646,
							33.496918
						],
						[
							-86.785556,
							33.497388
						],
						[
							-86.784784,
							33.497859
						],
						[
							-86.783774,
							33.498231
						],
						[
							-86.782764,
							33.49833
						],
						[
							-86.782972,
							33.499692
						],
						[
							-86.782585,
							33.500337
						],
						[
							-86.781962,
							33.500708
						],
						[
							-86.781248,
							33.500931
						],
						[
							-86.780595,
							33.50103
						],
						[
							-86.779882,
							33.500783
						],
						[
							-86.77596,
							33.502764
						],
						[
							-86.775425,
							33.503111
						],
						[
							-86.773732,
							33.505316
						],
						[
							-86.773138,
							33.505737
						],
						[
							-86.77186,
							33.50653
						],
						[
							-86.770523,
							33.507422
						],
						[
							-86.769157,
							33.507868
						],
						[
							-86.768443,
							33.508413
						],
						[
							-86.768087,
							33.508883
						],
						[
							-86.766988,
							33.509627
						],
						[
							-86.766186,
							33.50985
						],
						[
							-86.764878,
							33.510271
						],
						[
							-86.764522,
							33.511014
						],
						[
							-86.764076,
							33.511559
						],
						[
							-86.763333,
							33.511831
						],
						[
							-86.761878,
							33.511955
						],
						[
							-86.761343,
							33.512401
						],
						[
							-86.758669,
							33.509329
						]
					]
				]
			]
		},
		properties: {
			state: "AL",
			city: "Birmingham",
			name: "Redmont Park, Rockridge Park, Warwick Manor, and southern portion of Milner Heights",
			holc_id: "A2",
			holc_grade: "A",
			neighborhood_id: 193,
			area_description_data: {
				"5": "Both sales and rental prices in 1929 were off about 20% from 1926-28 peak. Location of property within this area will justify policy of holding for its value.",
				"6": "Redmont Park, Rockridge Park, Warwick Manor, and southern portion of Milner Heights A 2",
				"31": "83",
				"32": "8",
				"33": "4",
				"3n": "1936 No rentals 55 No rentals N/A 50-100 N/A",
				"3j": "N/A 10000-30000 61 10000-27500 1938 No sales N/A",
				"3g": "None None 18 (1000-3000)",
				"1d": "65%",
				"3m": "No rentals 25-200 No rentals",
				"3c": "2 15 15",
				"3l": "None Fair Fair",
				"3k": "Fair FPoor Fair",
				"4a": "Ample",
				"1c": "Dead-end railroad siding bisects area, but is infrequently used. Residents of south half of area required to pay school truition if students attend city schools (usually pertains to high school students)",
				"1b": "Highly restricted. About one-half of area is outsid of city and other half is on crest of mountain, overlooking city (about 200 feet above city). Large lots; well landscaped. Layout adds charm and appeal. Protected by mountain from industrial odors and noises of city.",
				"2e": "None",
				"2d": "N/a None",
				"2f": "None",
				"3q": "No rentals No rentals Good to fair",
				"1e": "Up",
				"4b": "Ample",
				"3b": "Brick Veneer Brick Veneer Brick Veneer and solid stone",
				"3h": "15000-50000 30000-150000 None",
				"3p": "No rentals Good to fair No rentals",
				"1a": "Sloping upward from valley to crest of Red Mountain",
				"3o": "No rentals N/A N/A 60-125 No rentals 67 1938",
				"2c": "None N/A",
				"3e": "100 98 100",
				"3f": "100 100 90",
				"2b": "5000-35000 (with few up too 100M)",
				"3i": "N/A 10000-30000 10000-37500 30000-100000 1936 61 N/A",
				"2a": "Executives, business men and retired professional men",
				"3d": "Excellent Good Good",
				"3a": "2 story singles 2 story singles 1-2 story singles",
				"2g": "N/A N/A Moderately"
			}
		}
	},
	{
		type: "Feature",
		geometry: {
			type: "MultiPolygon",
			coordinates: [
				[
					[
						[
							-86.756777,
							33.497543
						],
						[
							-86.751964,
							33.501349
						],
						[
							-86.746046,
							33.500903
						],
						[
							-86.745797,
							33.500159
						],
						[
							-86.745904,
							33.497038
						],
						[
							-86.746046,
							33.496621
						],
						[
							-86.752071,
							33.492102
						],
						[
							-86.752178,
							33.491745
						],
						[
							-86.75225,
							33.490437
						],
						[
							-86.75225,
							33.487791
						],
						[
							-86.752891,
							33.486899
						],
						[
							-86.753961,
							33.487642
						],
						[
							-86.754496,
							33.488832
						],
						[
							-86.762268,
							33.488921
						],
						[
							-86.762018,
							33.491924
						],
						[
							-86.75692,
							33.495789
						],
						[
							-86.756777,
							33.497543
						]
					]
				]
			]
		},
		properties: {
			state: "AL",
			city: "Birmingham",
			name: "Colonial Hills, Pine Crest (outside city limits)",
			holc_id: "A3",
			holc_grade: "A",
			neighborhood_id: 206,
			area_description_data: {
				"5": "Generally speaking, houses are not built in this area for rental purpose. Both sales and rental prices in 1929 were off about 20% from 1926-28 peak. Location of property within this area will justify policy of holdings for its value. This is a difficult area to classify and might almost be considered a \"high blue\".",
				"6": "A Colonial Hills, Pince Crest (outside city limits) 3",
				"31": "75",
				"32": "25",
				"33": "N/A",
				"2c": "N/A None",
				"4b": "Ample on conservative basis",
				"2g": "Moderately N/A N/A",
				"3e": "98 90 N/A",
				"3h": "N/A None 8500-15000",
				"3i": "66 5000-9000 N/A 7000-10000 N/A 1936 N/A",
				"1d": "20",
				"2f": "None",
				"3j": "1938 N/A N/A N/A 7000-10000 5000-9000 66",
				"3k": "N/A Good Fair",
				"3c": "2 10 N/A",
				"3g": "None 10 ($7000-10000) N/A",
				"3f": "90 N/A 100",
				"3q": "Good to fair N/A No rentals",
				"1e": "Up",
				"2e": "None",
				"3a": "N/A 1 story singles 1-2 story singles",
				"2a": "Executives, business men and few clerical workers",
				"3l": "Good Fair N/A",
				"2d": "None N/A",
				"3b": "Brick veneer N/A Brick veneer",
				"4a": "Ample on conservative basis",
				"1a": "Slightly rolling land in Shades Valley",
				"3m": "No rentals N/A 75-100",
				"3d": "N/A Excellent Good ",
				"1b": "Well landscaped lots. Lay-out adds charm and appeal. Located betwen two high grade country clubs. Outside of city, hence subject to lower taxation. Convenient to grade schools. Highly restricted. Protected by mountains from industrial odors and noises of city.",
				"1c": "Residents must pay school truition if studetns attend high school in city.",
				"3p": "N/A Good to fair No rentals",
				"2b": "2500-10000",
				"3n": "No rentals N/A N/A N/A 1936 40-55 54",
				"3o": "No rentals 50-65 66 N/A N/A 1938 N/A"
			}
		}
	}
];
export default {
	type: type,
	features: features
};
