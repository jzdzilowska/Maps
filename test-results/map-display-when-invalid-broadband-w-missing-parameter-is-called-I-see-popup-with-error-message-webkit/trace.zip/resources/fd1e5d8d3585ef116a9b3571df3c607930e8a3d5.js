import * as mockedJson from "/src/frontend/components/map/mockGeoJson.json?import";
const propertyName = "holc_grade";
export const geoLayer = {
  id: "redlining",
  type: "fill",
  paint: {
    "fill-color": [
      "match",
      ["get", propertyName],
      "A",
      "#5bcc04",
      "B",
      "#04b8cc",
      "C",
      "#e9ed0e",
      "D",
      "#d11d1d",
      "#ccc"
    ],
    "fill-opacity": 0.2
  }
};
export const filteredLayer = {
  id: "filteredLayer",
  type: "fill",
  paint: {
    "fill-color": "#fe3fb3",
    "fill-opacity": 0.6
  }
};
function isFeatureCollection(json) {
  return json.type === "FeatureCollection";
}
export async function fetchRedliningData() {
  try {
    const response = await fetch(
      "http://localhost:3232/redlining?minLat=-90&maxLat=90&minLon=-180&maxLon=180"
    );
    if (response.ok) {
      const data = await response.json();
      if (data.result === "success") {
        return isFeatureCollection(data.data) ? data.data : void 0;
      }
    }
  } catch (error) {
    return void 0;
  }
}
export async function fetchFilteredData(keyword) {
  try {
    const words = keyword.replace(/_/g, " ");
    const response = await fetch(
      `http://localhost:3232/filter?keyword=${words}`
    );
    if (response.ok) {
      const data = await response.json();
      if (data.result === "success") {
        return isFeatureCollection(data.data) ? data.data : void 0;
      }
    }
  } catch (error) {
    return void 0;
  }
}
export async function fetchMockedData() {
  try {
    return isFeatureCollection(mockedJson) ? mockedJson : void 0;
  } catch (error) {
    return void 0;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm92ZXJsYXlzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZlYXR1cmVDb2xsZWN0aW9uIH0gZnJvbSBcImdlb2pzb25cIjtcbmltcG9ydCB7IEZpbGxMYXllciB9IGZyb20gXCJyZWFjdC1tYXAtZ2xcIjtcbmltcG9ydCB7IGlzR2VuZXJhdG9yRnVuY3Rpb24gfSBmcm9tIFwidXRpbC90eXBlc1wiO1xuaW1wb3J0ICogYXMgZnMgZnJvbSBcImZzL3Byb21pc2VzXCI7XG5pbXBvcnQgKiBhcyBtb2NrZWRKc29uIGZyb20gXCIuL21vY2tHZW9Kc29uLmpzb25cIjtcblxuY29uc3QgcHJvcGVydHlOYW1lID0gXCJob2xjX2dyYWRlXCI7XG5leHBvcnQgY29uc3QgZ2VvTGF5ZXI6IEZpbGxMYXllciA9IHtcbiAgaWQ6IFwicmVkbGluaW5nXCIsXG4gIHR5cGU6IFwiZmlsbFwiLFxuICBwYWludDoge1xuICAgIFwiZmlsbC1jb2xvclwiOiBbXG4gICAgICBcIm1hdGNoXCIsXG4gICAgICBbXCJnZXRcIiwgcHJvcGVydHlOYW1lXSxcbiAgICAgIFwiQVwiLFxuICAgICAgXCIjNWJjYzA0XCIsXG4gICAgICBcIkJcIixcbiAgICAgIFwiIzA0YjhjY1wiLFxuICAgICAgXCJDXCIsXG4gICAgICBcIiNlOWVkMGVcIixcbiAgICAgIFwiRFwiLFxuICAgICAgXCIjZDExZDFkXCIsXG4gICAgICBcIiNjY2NcIixcbiAgICBdLFxuICAgIFwiZmlsbC1vcGFjaXR5XCI6IDAuMixcbiAgfSxcbn07XG5cbmV4cG9ydCBjb25zdCBmaWx0ZXJlZExheWVyOiBGaWxsTGF5ZXIgPSB7XG4gIGlkOiBcImZpbHRlcmVkTGF5ZXJcIixcbiAgdHlwZTogXCJmaWxsXCIsXG4gIHBhaW50OiB7XG4gICAgXCJmaWxsLWNvbG9yXCI6IFwiI2ZlM2ZiM1wiLFxuICAgIFwiZmlsbC1vcGFjaXR5XCI6IDAuNixcbiAgfSxcbn07XG5cbmZ1bmN0aW9uIGlzRmVhdHVyZUNvbGxlY3Rpb24oanNvbjogYW55KToganNvbiBpcyBGZWF0dXJlQ29sbGVjdGlvbiB7XG4gIHJldHVybiBqc29uLnR5cGUgPT09IFwiRmVhdHVyZUNvbGxlY3Rpb25cIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoUmVkbGluaW5nRGF0YSgpOiBQcm9taXNlPFxuICBHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uIHwgdW5kZWZpbmVkXG4+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxuICAgICAgXCJodHRwOi8vbG9jYWxob3N0OjMyMzIvcmVkbGluaW5nP21pbkxhdD0tOTAmbWF4TGF0PTkwJm1pbkxvbj0tMTgwJm1heExvbj0xODBcIlxuICAgICk7XG4gICAgaWYgKHJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgLy8gcmV0dXJuIGlzRmVhdHVyZUNvbGxlY3Rpb24oZGF0YSkgPyBkYXRhIDogdW5kZWZpbmVkO1xuICAgICAgaWYgKGRhdGEucmVzdWx0ID09PSBcInN1Y2Nlc3NcIikge1xuICAgICAgICByZXR1cm4gaXNGZWF0dXJlQ29sbGVjdGlvbihkYXRhLmRhdGEpID8gZGF0YS5kYXRhIDogdW5kZWZpbmVkO1xuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaEZpbHRlcmVkRGF0YShcbiAga2V5d29yZDogU3RyaW5nXG4pOiBQcm9taXNlPEdlb0pTT04uRmVhdHVyZUNvbGxlY3Rpb24gfCB1bmRlZmluZWQ+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCB3b3JkcyA9IGtleXdvcmQucmVwbGFjZSgvXy9nLCBcIiBcIik7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcbiAgICAgIGBodHRwOi8vbG9jYWxob3N0OjMyMzIvZmlsdGVyP2tleXdvcmQ9JHt3b3Jkc31gXG4gICAgKTtcbiAgICBpZiAocmVzcG9uc2Uub2spIHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICBpZiAoZGF0YS5yZXN1bHQgPT09IFwic3VjY2Vzc1wiKSB7XG4gICAgICAgIHJldHVybiBpc0ZlYXR1cmVDb2xsZWN0aW9uKGRhdGEuZGF0YSkgPyBkYXRhLmRhdGEgOiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoTW9ja2VkRGF0YSgpOiBQcm9taXNlPFxuICBHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uIHwgdW5kZWZpbmVkXG4+IHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gaXNGZWF0dXJlQ29sbGVjdGlvbihtb2NrZWRKc29uKSA/IG1vY2tlZEpzb24gOiB1bmRlZmluZWQ7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFJQSxZQUFZLGdCQUFnQjtBQUU1QixNQUFNLGVBQWU7QUFDZCxhQUFNLFdBQXNCO0FBQUEsRUFDakMsSUFBSTtBQUFBLEVBQ0osTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLElBQ0wsY0FBYztBQUFBLE1BQ1o7QUFBQSxNQUNBLENBQUMsT0FBTyxZQUFZO0FBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLEVBQ2xCO0FBQ0Y7QUFFTyxhQUFNLGdCQUEyQjtBQUFBLEVBQ3RDLElBQUk7QUFBQSxFQUNKLE1BQU07QUFBQSxFQUNOLE9BQU87QUFBQSxJQUNMLGNBQWM7QUFBQSxJQUNkLGdCQUFnQjtBQUFBLEVBQ2xCO0FBQ0Y7QUFFQSxTQUFTLG9CQUFvQixNQUFzQztBQUNqRSxTQUFPLEtBQUssU0FBUztBQUN2QjtBQUVBLHNCQUFzQixxQkFFcEI7QUFDQSxNQUFJO0FBQ0YsVUFBTSxXQUFXLE1BQU07QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFNBQVMsSUFBSTtBQUNmLFlBQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztBQUVqQyxVQUFJLEtBQUssV0FBVyxXQUFXO0FBQzdCLGVBQU8sb0JBQW9CLEtBQUssSUFBSSxJQUFJLEtBQUssT0FBTztBQUFBLE1BQ3REO0FBQUEsSUFDRjtBQUFBLEVBQ0YsU0FBUyxPQUFPO0FBQ2QsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLHNCQUFzQixrQkFDcEIsU0FDZ0Q7QUFDaEQsTUFBSTtBQUNGLFVBQU0sUUFBUSxRQUFRLFFBQVEsTUFBTSxHQUFHO0FBQ3ZDLFVBQU0sV0FBVyxNQUFNO0FBQUEsTUFDckIsd0NBQXdDLEtBQUs7QUFBQSxJQUMvQztBQUNBLFFBQUksU0FBUyxJQUFJO0FBQ2YsWUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0FBQ2pDLFVBQUksS0FBSyxXQUFXLFdBQVc7QUFDN0IsZUFBTyxvQkFBb0IsS0FBSyxJQUFJLElBQUksS0FBSyxPQUFPO0FBQUEsTUFDdEQ7QUFBQSxJQUNGO0FBQUEsRUFDRixTQUFTLE9BQU87QUFDZCxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsc0JBQXNCLGtCQUVwQjtBQUNBLE1BQUk7QUFDRixXQUFPLG9CQUFvQixVQUFVLElBQUksYUFBYTtBQUFBLEVBQ3hELFNBQVMsT0FBTztBQUNkLFdBQU87QUFBQSxFQUNUO0FBQ0Y7IiwibmFtZXMiOltdfQ==