import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/map/MapInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b2f08eeb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/MapInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b2f08eeb"; const useState = __vite__cjsImport3_react["useState"];
import { ControlledInput } from "/src/frontend/components/ControlledInput.tsx";
export function MapInput(props) {
  _s();
  const [mapCommandString, setmapCommandString] = useState("");
  const {
    ariaLabel,
    focusMap,
    addFilteredLayer
  } = props;
  const handleBroadband = async (args) => {
    if (args.length !== 2) {
      alert("Invalid broadband retrieval command. Usage: broadband <state> <county>");
      return;
    }
    const state = args[0].replace(/_/g, " ");
    const county = args[1].replace(/_/g, " ");
    try {
      const response = await fetch(`http://localhost:3232/broadband?state=${state}&county=${county}`);
      if (response.ok) {
        const data = await response.json();
        if (data.result === "success") {
          const percentage = data.broadband_access_percent;
          focusMap(state, county, percentage);
        } else {
          alert("Failed to retrieve broadband data: " + data.error_message);
        }
      } else
        alert("Failed to fetch data from the backend");
    } catch (error) {
      alert("An error occurred while fetching broadband data: " + error);
    }
  };
  const handleFilter = async (args) => {
    if (args.length !== 1) {
      alert("Invalid search command. Usage: search your_keyword");
      return;
    }
    addFilteredLayer(args[0]);
  };
  const handleMockFilter = async (args) => {
    if (args.length !== 1) {
      alert("Invalid search command. Usage: search your_keyword");
      return;
    }
    addFilteredLayer(args[0]);
  };
  function handleSubmit(commandString) {
    const trimmedCommand = commandString.trim();
    if (trimmedCommand === "") {
      alert("Command cannot be empty");
      return;
    }
    const args = trimmedCommand.split(/\s+/);
    const queries = args.slice(1);
    if (args[0] === "broadband") {
      handleBroadband(queries);
    } else if (args[0] === "search") {
      handleFilter(queries);
    } else if (args[0] === "mocksearch") {
      handleMockFilter(queries);
    } else {
      alert("Improper command");
    }
    setmapCommandString("");
  }
  function handleEnterPress(e) {
    if (e.key === "Enter") {
      handleSubmit(mapCommandString);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "map-input", "aria-live": "polite", "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/MapInput.tsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: mapCommandString, setValue: setmapCommandString, ariaLabel: "Command Input Box to type in commands", onKeyDown: handleEnterPress }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/MapInput.tsx",
        lineNumber: 115,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/MapInput.tsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(mapCommandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/MapInput.tsx",
      lineNumber: 117,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/MapInput.tsx",
    lineNumber: 112,
    columnNumber: 10
  }, this);
}
_s(MapInput, "PnTJYI+BrwNfbIfweElOWhSefJ0=");
_c = MapInput;
var _c;
$RefreshReg$(_c, "MapInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/MapInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUhROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5IUixTQUFtQ0EsZ0JBQWdCO0FBQ25ELFNBQVNDLHVCQUF1QjtBQWdCekIsZ0JBQVNDLFNBQVNDLE9BQXNCO0FBQUFDLEtBQUE7QUFDN0MsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJTixTQUFpQixFQUFFO0FBQ25FLFFBQU07QUFBQSxJQUFFTztBQUFBQSxJQUFXQztBQUFBQSxJQUFVQztBQUFBQSxFQUFpQixJQUFJTjtBQVFsRCxRQUFNTyxrQkFBa0IsT0FBT0MsU0FBbUI7QUFDaEQsUUFBSUEsS0FBS0MsV0FBVyxHQUFHO0FBQ3JCQyxZQUNFLHdFQUNGO0FBQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTUMsUUFBUUgsS0FBSyxDQUFDLEVBQUVJLFFBQVEsTUFBTSxHQUFHO0FBQ3ZDLFVBQU1DLFNBQVNMLEtBQUssQ0FBQyxFQUFFSSxRQUFRLE1BQU0sR0FBRztBQUV4QyxRQUFJO0FBQ0YsWUFBTUUsV0FBVyxNQUFNQyxNQUNwQix5Q0FBd0NKLEtBQU0sV0FBVUUsTUFBTyxFQUNsRTtBQUNBLFVBQUlDLFNBQVNFLElBQUk7QUFDZixjQUFNQyxPQUFPLE1BQU1ILFNBQVNJLEtBQUs7QUFDakMsWUFBSUQsS0FBS0UsV0FBVyxXQUFXO0FBQzdCLGdCQUFNQyxhQUFhSCxLQUFLSTtBQUN4QmhCLG1CQUFTTSxPQUFPRSxRQUFRTyxVQUFVO0FBQUEsUUFDcEMsT0FBTztBQUNMVixnQkFBTSx3Q0FBd0NPLEtBQUtLLGFBQWE7QUFBQSxRQUNsRTtBQUFBLE1BQ0Y7QUFBT1osY0FBTSx1Q0FBdUM7QUFBQSxJQUN0RCxTQUFTYSxPQUFPO0FBQ2RiLFlBQU0sc0RBQXNEYSxLQUFLO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBRUEsUUFBTUMsZUFBZSxPQUFPaEIsU0FBbUI7QUFDN0MsUUFBSUEsS0FBS0MsV0FBVyxHQUFHO0FBQ3JCQyxZQUFNLG9EQUFvRDtBQUMxRDtBQUFBLElBQ0Y7QUFDQUoscUJBQWlCRSxLQUFLLENBQUMsQ0FBQztBQUFBLEVBQzFCO0FBRUEsUUFBTWlCLG1CQUFtQixPQUFPakIsU0FBbUI7QUFDakQsUUFBSUEsS0FBS0MsV0FBVyxHQUFHO0FBQ3JCQyxZQUFNLG9EQUFvRDtBQUMxRDtBQUFBLElBQ0Y7QUFDQUoscUJBQWlCRSxLQUFLLENBQUMsQ0FBQztBQUFBLEVBQzFCO0FBTUEsV0FBU2tCLGFBQWFDLGVBQXVCO0FBQzNDLFVBQU1DLGlCQUFpQkQsY0FBY0UsS0FBSztBQUMxQyxRQUFJRCxtQkFBbUIsSUFBSTtBQUN6QmxCLFlBQU0seUJBQXlCO0FBQy9CO0FBQUEsSUFDRjtBQUdBLFVBQU1GLE9BQU9vQixlQUFlRSxNQUFNLEtBQUs7QUFDdkMsVUFBTUMsVUFBVXZCLEtBQUt3QixNQUFNLENBQUM7QUFFNUIsUUFBSXhCLEtBQUssQ0FBQyxNQUFNLGFBQWE7QUFDM0JELHNCQUFnQndCLE9BQU87QUFBQSxJQUN6QixXQUFXdkIsS0FBSyxDQUFDLE1BQU0sVUFBVTtBQUMvQmdCLG1CQUFhTyxPQUFPO0FBQUEsSUFDdEIsV0FBV3ZCLEtBQUssQ0FBQyxNQUFNLGNBQWM7QUFDbkNpQix1QkFBaUJNLE9BQU87QUFBQSxJQUMxQixPQUFPO0FBQ0xyQixZQUFNLGtCQUFrQjtBQUFBLElBQzFCO0FBQ0FQLHdCQUFvQixFQUFFO0FBQUEsRUFDeEI7QUFRQSxXQUFTOEIsaUJBQWlCQyxHQUF3QjtBQUNoRCxRQUFJQSxFQUFFQyxRQUFRLFNBQVM7QUFDckJULG1CQUFheEIsZ0JBQWdCO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBSUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFBWSxhQUFVLFVBQVMsY0FBWUUsV0FDeEQ7QUFBQSwyQkFBQyxjQUNDO0FBQUEsNkJBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsTUFDeEIsdUJBQUMsbUJBQ0MsT0FBT0Ysa0JBQ1AsVUFBVUMscUJBQ1YsV0FBVyx5Q0FDWCxXQUFXOEIsb0JBSmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUk4QjtBQUFBLFNBTmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU1QLGFBQWF4QixnQkFBZ0IsR0FBRyxzQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RDtBQUFBLE9BVi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVKO0FBQUNELEdBN0dlRixVQUFRO0FBQUFxQyxLQUFSckM7QUFBUSxJQUFBcUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwiTWFwSW5wdXQiLCJwcm9wcyIsIl9zIiwibWFwQ29tbWFuZFN0cmluZyIsInNldG1hcENvbW1hbmRTdHJpbmciLCJhcmlhTGFiZWwiLCJmb2N1c01hcCIsImFkZEZpbHRlcmVkTGF5ZXIiLCJoYW5kbGVCcm9hZGJhbmQiLCJhcmdzIiwibGVuZ3RoIiwiYWxlcnQiLCJzdGF0ZSIsInJlcGxhY2UiLCJjb3VudHkiLCJyZXNwb25zZSIsImZldGNoIiwib2siLCJkYXRhIiwianNvbiIsInJlc3VsdCIsInBlcmNlbnRhZ2UiLCJicm9hZGJhbmRfYWNjZXNzX3BlcmNlbnQiLCJlcnJvcl9tZXNzYWdlIiwiZXJyb3IiLCJoYW5kbGVGaWx0ZXIiLCJoYW5kbGVNb2NrRmlsdGVyIiwiaGFuZGxlU3VibWl0IiwiY29tbWFuZFN0cmluZyIsInRyaW1tZWRDb21tYW5kIiwidHJpbSIsInNwbGl0IiwicXVlcmllcyIsInNsaWNlIiwiaGFuZGxlRW50ZXJQcmVzcyIsImUiLCJrZXkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1hcElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi4vQ29udHJvbGxlZElucHV0XCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBQcm9wcyBmb3IgdGhlIE1hcElucHV0IGNvbXBvbmVudFxuICovXG5pbnRlcmZhY2UgTWFwSW5wdXRQcm9wcyB7XG4gIGFyaWFMYWJlbDogc3RyaW5nO1xuICBmb2N1c01hcDogKHN0YXRlOiBzdHJpbmcsIGNvdW50eTogc3RyaW5nLCBicm9hZGJhbmQ6IHN0cmluZykgPT4gdm9pZDtcbiAgYWRkRmlsdGVyZWRMYXllcjogKGtleXdvcmQ6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuLyoqXG4gKiBSZWFjdCBjb21wb25lbnQgcmVzcG9uc2libGUgZm9yIGhhbmRsaW5nIHVzZXIgaW5wdXQgYW5kIGV4ZWN1dGluZyBjb21tYW5kc1xuICogQHBhcmFtIHtSRVBMSW5wdXRQcm9wc30gcHJvcHMgLSBUaGUgcHJvcGVydGllcyByZXF1aXJlZCBmb3IgcmVuZGVyaW5nIHRoZSBjb21wb25lbnRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE1hcElucHV0KHByb3BzOiBNYXBJbnB1dFByb3BzKSB7XG4gIGNvbnN0IFttYXBDb21tYW5kU3RyaW5nLCBzZXRtYXBDb21tYW5kU3RyaW5nXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGNvbnN0IHsgYXJpYUxhYmVsLCBmb2N1c01hcCwgYWRkRmlsdGVyZWRMYXllciB9ID0gcHJvcHM7XG5cbiAgLyoqXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIHJldHJpZXZpbmcgYnJvYWRiYW5kIGFjY2VzcyBwZXJjZW50YWdlIHZpYSB0aGUgTWFwJ3MgY29tbWFuZGxpbmUgYW5kIGRpc3BsYXlpbmcgdGhlXG4gICAqIGFwcHJvcHJpYXRlIHBvcHVwXG4gICAqXG4gICAqIEBwYXJhbSB7c3RyaW5nW119IGFyZ3MgLSBUaGUgYnJvYWRiYW5kIHF1ZXJ5IHBhcmFtZXRlcnNcbiAgICovXG4gIGNvbnN0IGhhbmRsZUJyb2FkYmFuZCA9IGFzeW5jIChhcmdzOiBzdHJpbmdbXSkgPT4ge1xuICAgIGlmIChhcmdzLmxlbmd0aCAhPT0gMikge1xuICAgICAgYWxlcnQoXG4gICAgICAgIFwiSW52YWxpZCBicm9hZGJhbmQgcmV0cmlldmFsIGNvbW1hbmQuIFVzYWdlOiBicm9hZGJhbmQgPHN0YXRlPiA8Y291bnR5PlwiXG4gICAgICApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBzdGF0ZSA9IGFyZ3NbMF0ucmVwbGFjZSgvXy9nLCBcIiBcIik7XG4gICAgY29uc3QgY291bnR5ID0gYXJnc1sxXS5yZXBsYWNlKC9fL2csIFwiIFwiKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxuICAgICAgICBgaHR0cDovL2xvY2FsaG9zdDozMjMyL2Jyb2FkYmFuZD9zdGF0ZT0ke3N0YXRlfSZjb3VudHk9JHtjb3VudHl9YFxuICAgICAgKTtcbiAgICAgIGlmIChyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBpZiAoZGF0YS5yZXN1bHQgPT09IFwic3VjY2Vzc1wiKSB7XG4gICAgICAgICAgY29uc3QgcGVyY2VudGFnZSA9IGRhdGEuYnJvYWRiYW5kX2FjY2Vzc19wZXJjZW50O1xuICAgICAgICAgIGZvY3VzTWFwKHN0YXRlLCBjb3VudHksIHBlcmNlbnRhZ2UpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGFsZXJ0KFwiRmFpbGVkIHRvIHJldHJpZXZlIGJyb2FkYmFuZCBkYXRhOiBcIiArIGRhdGEuZXJyb3JfbWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBhbGVydChcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIik7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGFsZXJ0KFwiQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgZmV0Y2hpbmcgYnJvYWRiYW5kIGRhdGE6IFwiICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVGaWx0ZXIgPSBhc3luYyAoYXJnczogc3RyaW5nW10pID0+IHtcbiAgICBpZiAoYXJncy5sZW5ndGggIT09IDEpIHtcbiAgICAgIGFsZXJ0KFwiSW52YWxpZCBzZWFyY2ggY29tbWFuZC4gVXNhZ2U6IHNlYXJjaCB5b3VyX2tleXdvcmRcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGFkZEZpbHRlcmVkTGF5ZXIoYXJnc1swXSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTW9ja0ZpbHRlciA9IGFzeW5jIChhcmdzOiBzdHJpbmdbXSkgPT4ge1xuICAgIGlmIChhcmdzLmxlbmd0aCAhPT0gMSkge1xuICAgICAgYWxlcnQoXCJJbnZhbGlkIHNlYXJjaCBjb21tYW5kLiBVc2FnZTogc2VhcmNoIHlvdXJfa2V5d29yZFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYWRkRmlsdGVyZWRMYXllcihhcmdzWzBdKTtcbiAgfTtcblxuICAvKipcbiAgICogRnVuY3Rpb24gdHJpZ2dlcmVkIHdoZW4gdGhlIFwiU3VibWl0XCIgYnV0dG9uIGlzIGNsaWNrZWQgdG8gcHJvY2VzcyB0aGUgdXNlcidzIGNvbW1hbmRcbiAgICogQHBhcmFtIHtzdHJpbmd9IGNvbW1hbmRTdHJpbmcgLSBUaGUgd2hvbGUgdXNlciBpbnB1dFxuICAgKi9cbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmc6IHN0cmluZykge1xuICAgIGNvbnN0IHRyaW1tZWRDb21tYW5kID0gY29tbWFuZFN0cmluZy50cmltKCk7XG4gICAgaWYgKHRyaW1tZWRDb21tYW5kID09PSBcIlwiKSB7XG4gICAgICBhbGVydChcIkNvbW1hbmQgY2Fubm90IGJlIGVtcHR5XCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIGFycmF5IG9mIGFsbCB3b3JkcyBlbnRlcmVkIGJ5IHVzZXIgaW4gdGhlIGNvbW1hbmQgaW5wdXRcbiAgICBjb25zdCBhcmdzID0gdHJpbW1lZENvbW1hbmQuc3BsaXQoL1xccysvKTtcbiAgICBjb25zdCBxdWVyaWVzID0gYXJncy5zbGljZSgxKTtcbiAgICAvLyBjaGVja2luZyBpZiBjYWxsIGZvciBicm9hZGJhbmQgLSBhc3N1bWluZyB0aGUgZW5kIHVzZXIgaXMgbm90IGEgZGV2ZWxvcGVyIGFzIG1lbnRpb25lZCwgY2FuIGJlIFwiaGFyZC1jb2RlZFwiXG4gICAgaWYgKGFyZ3NbMF0gPT09IFwiYnJvYWRiYW5kXCIpIHtcbiAgICAgIGhhbmRsZUJyb2FkYmFuZChxdWVyaWVzKTtcbiAgICB9IGVsc2UgaWYgKGFyZ3NbMF0gPT09IFwic2VhcmNoXCIpIHtcbiAgICAgIGhhbmRsZUZpbHRlcihxdWVyaWVzKTtcbiAgICB9IGVsc2UgaWYgKGFyZ3NbMF0gPT09IFwibW9ja3NlYXJjaFwiKSB7XG4gICAgICBoYW5kbGVNb2NrRmlsdGVyKHF1ZXJpZXMpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhbGVydChcIkltcHJvcGVyIGNvbW1hbmRcIik7XG4gICAgfVxuICAgIHNldG1hcENvbW1hbmRTdHJpbmcoXCJcIik7XG4gIH1cblxuICAvLyBBbGwga2V5Ym9hcmQgc2hvcnRjdXRzIGhlcmVcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBIYW5kbGVzIGtleWJvYXJkIHNob3J0Y3V0IHRvIHN1Ym1pdCBieSBwcmVzc2luZyBFbnRlciBpbiBjb21tYW5kIGJveFxuICAgKiBAcGFyYW0gZSBrZXlib2FyZCBldmVudCBvZiBwcmVzc2luZyBFbnRlciBrZXlcbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZUVudGVyUHJlc3MoZTogUmVhY3QuS2V5Ym9hcmRFdmVudCkge1xuICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XG4gICAgICBoYW5kbGVTdWJtaXQobWFwQ29tbWFuZFN0cmluZyk7XG4gICAgfVxuICB9XG5cbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWlucHV0XCIgYXJpYS1saXZlPVwicG9saXRlXCIgYXJpYS1sYWJlbD17YXJpYUxhYmVsfT5cbiAgICAgIDxmaWVsZHNldD5cbiAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XG4gICAgICAgIDxDb250cm9sbGVkSW5wdXRcbiAgICAgICAgICB2YWx1ZT17bWFwQ29tbWFuZFN0cmluZ31cbiAgICAgICAgICBzZXRWYWx1ZT17c2V0bWFwQ29tbWFuZFN0cmluZ31cbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBJbnB1dCBCb3ggdG8gdHlwZSBpbiBjb21tYW5kc1wifVxuICAgICAgICAgIG9uS2V5RG93bj17aGFuZGxlRW50ZXJQcmVzc31cbiAgICAgICAgLz5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1Ym1pdChtYXBDb21tYW5kU3RyaW5nKX0+U3VibWl0PC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy96ZHppbG93c2thL0Rlc2t0b3AvdW5pdmVyc2l0eS95ZWFyIDIvY3MwMzIwL21hcHMtanpkemlsb3ctc3BzYW5kb3Yvc3JjL2Zyb250ZW5kL2NvbXBvbmVudHMvbWFwL01hcElucHV0LnRzeCJ9